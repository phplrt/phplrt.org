<?php

declare(strict_types=1);

namespace Calculator\Node;

final class Addition extends BinaryExpression
{
}
