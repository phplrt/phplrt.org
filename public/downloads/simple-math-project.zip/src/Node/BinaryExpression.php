<?php

declare(strict_types=1);

namespace Calculator\Node;

abstract class BinaryExpression extends Expression
{
    public Expression $a;
    public Expression $b;

    public function __construct(Expression $a, Expression $b)
    {
        $this->a = $a;
        $this->b = $b;
    }
}
