<?php

declare(strict_types=1);

namespace Calculator\Node;

abstract class Literal extends Expression
{
}
