<?php

declare(strict_types=1);

require __DIR__ . '/vendor/autoload.php';
require __DIR__ . '/bin/build.php';

$math = new \Calculator\Parser();

$ast = $math->parse('2 + 2 + 4');

dump($ast);
